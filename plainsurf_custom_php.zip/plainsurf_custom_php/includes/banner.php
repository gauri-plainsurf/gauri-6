
<section class="banner layer" id="home">
	<div class="container">
		<div class="banner-text">
			<div class="slider-info mb-4">
				<div class="agileinfo-logo">
					<h3>
						Practice makes you better
					</h3>
				</div>
				<h3 class="txt-w3_agile mb-3"> Its time to master your skills</h3>
				<a href="course.html" class="mr-2"><i class="fas fa-graduation-cap"></i> Our Courses</a>
				<a href="about.html"><i class="fas fa-book"></i> Read More</a>
			</div>
			<!-- To bottom button-->
			<div class="thim-click-to-bottom">
				<div class="rotate">
					<a href="#welcome" class="scroll">
						<i class="fas fa-angle-double-down"></i>
					</a>
				</div>
			</div>
			<!-- //To bottom button-->

		</div>
	</div>
</section>
