<div class="inner_banner layer" id="home">
        <div class="container">
		<div class="agileinfo-inner">
			<h2 class="text-center text-white">
				About Page
			</h2>
		</div>
        </div>
</div>